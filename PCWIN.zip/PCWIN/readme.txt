PCWIN.exe

This is a Trojan
Run on a VM only!
Use it as long as POSSIBLE! :D